// Import stylesheets
import "./style.css";


// Write TypeScript code!
const appDiv: HTMLElement = document.getElementById("app");
appDiv.innerHTML = `<h1>/̵͇̿̿/'̿'̿ ̿ ̿̿ ̿̿ ̿̿
🤯</h1>`;



import { names } from "./const";
import { Animal } from "./Animal";
import { getRandomName, generateLeg,} from
 "./xd";
let animalxdd: Animal[] = [];

for (let i = 0; i < 50; i++) {
  let animalxd: Animal = {
    name: getRandomName(),
    isMammal: Math.random() >= 0.5,
    legsCount: generateLeg(1),
   
    
    
   
    
  };
 animalxdd.push(animalxd);
}
let televanafaszommar = 1;
animalxdd.forEach(x => {let p = document.createElement("p");
  p.innerHTML =`${televanafaszommar}. Nev: ${x.name} - Labak Szama: ${x.legsCount} - Emlos-e? <input type="checkbox" ${x.isMammal ? "checked" : ""
  }>`;
  televanafaszommar++;
  if(televanafaszommar%2==1)
  { 
   p.style.fontWeight=900;
     
  }
  
  
  document.body.appendChild(p);
});


console.log(animalxdd);