
export interface Animal{
name: string;

isMammal: boolean;

legsCount: number[];





}