import { names } from "./const";

export function getRndInteger(min: number, max: number): number {
  return Math.floor(Math.random() * (max - min)) + min;
}

export function getRandomName(): string {
  let randomNumber = getRndInteger(0, names.length);
  return names[randomNumber];
}
export function generateLeg(count: number): number[] {
  let numbers: number[] = [];
  for (let i = 0; i < count; i++) {
    numbers.push(getRndInteger(1, 5));
  }
  return numbers;
}
